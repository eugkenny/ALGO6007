/******************************************************************************
* Data Structures Assignment 1
*
* Name: YOUR NAME HERE
* ID: YOUR K NUMBER HERE
* Course: YOUR COURSE HERE
*
******************************************************************************/
public class Percolation{
	
	public Percolation( int N){
		// YOUR CODE HERE
	}

	public void open( int i, int j){
		// YOUR CODE HERE
	}
	
	public boolean isOpen( int i, int j){
		// YOUR CODE HERE
	}
	
	public boolean isFull( int i, int j){
		// YOUR CODE HERE
	}
	
	public boolean percolates(){
		// YOUR CODE HERE
	}
	
	public static void main(String [] args){
	    int N = 5
	    Percolation p = new Percolation(N);
	    
	    
	}
}
